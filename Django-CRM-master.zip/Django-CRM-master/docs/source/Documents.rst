Documents
*********



|  **Fig** documents Home Page

|  The above figure shows the documents view, this page gives details and list view of leads
|  You can filter the results by title, status, shared to.

|  Create a new Document using the button on right corner ``+ Add New Document``


|  **Fig** Documents Create Page

|  **Note:** Fields having ``*`` are mandatory.
