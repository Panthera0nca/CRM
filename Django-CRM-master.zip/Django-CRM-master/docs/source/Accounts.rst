Accounts
********

|  These have the user roles i.e Admin and User. User Role will have permissions where Admin can access.

|  Create your Accounts  - new account can be created for different users and contacts and leads can create in accounts itself in their view pages




|  **Fig** Accounts page

|  This page view describes us about the accounts available and basic information.

|  There are 2 types of accounts i.e Open/Closed accounts.

|  We can Edit/Delete accounts here

|  To create an account we have a option "Add New Account" at the top right corner On Clicking it you will be redirected to the below page.

|  **Optional:** We can filter the users based on name,city,tags .


|  **Fig** Account create page

|  Here while we are creating an account, it is mandatory to have minimum one contact and one lead.

|  **Note:** Fields having ``*`` are mandatory





.. |  Rules to follow:-

.. 1.writing test cases for the code

.. 2.test cases coverage percent should be above 90%
